A Hypergraph Created for Bradley Research
