
public interface Constraint
{
    
}
