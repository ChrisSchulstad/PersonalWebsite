
public class Action
{
    private Verb _verb;
    private Noun _noun;
    
    public Action(Verb theVerb, Noun theNoun)
    {
        
    }
}
