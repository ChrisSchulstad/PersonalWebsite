
import java.util.ArrayList;

public class Noun
{
    private ArrayList<Verb> _allowable;
    
    public Noun(ArrayList<Verb> allowable)
    {
        _allowable = allowable;
    }
}
